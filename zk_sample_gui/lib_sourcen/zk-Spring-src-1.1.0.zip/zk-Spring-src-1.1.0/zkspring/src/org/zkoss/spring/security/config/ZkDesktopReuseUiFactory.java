/* ZkDesktopReuseUiFactory.java

{{IS_NOTE
	Purpose:
		
	Description:
		
	History:
		Dec 11, 2008 3:11:20 PM, Created by henrichen
}}IS_NOTE

Copyright (C) 2008 Potix Corporation. All Rights Reserved.

{{IS_RIGHT
	This program is distributed under GPL Version 2.0 in the hope that
	it will be useful, but WITHOUT ANY WARRANTY.
}}IS_RIGHT
*/

package org.zkoss.spring.security.config;

import javax.servlet.ServletRequest;

import org.zkoss.web.servlet.http.Https;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Desktop;
import org.zkoss.zk.ui.Execution;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.Page;
import org.zkoss.zk.ui.Richlet;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zk.ui.http.SimpleUiFactory;
import org.zkoss.zk.ui.impl.PageImpl;
import org.zkoss.zk.ui.metainfo.PageDefinition;
import org.zkoss.zk.ui.metainfo.PageDefinitions;
import org.zkoss.zk.ui.sys.PageConfig;
import org.zkoss.zk.ui.sys.RequestInfo;

/**
 * Handle new page creation issue when reuse desktop.
 * Used in changing page from http to https
 * @author henrichen
 * @since 1.1
 */
public class ZkDesktopReuseUiFactory extends SimpleUiFactory {
	public static final String DESKTOP_REUSE = "zkoss.spring.DESKTOP_REUSE";
	public static final String DESKTOP_URL = "zkoss.spring.DESKTOP_URL";

	public PageDefinition getPageDefinition(RequestInfo ri, String path) {
		final ServletRequest request = (ServletRequest) ri.getNativeRequest();
		if (request.getAttribute(DESKTOP_REUSE) != null) {
			//when reuse, prepare an empty page definition
			return PageDefinitions.getPageDefinitionDirectly(ri.getWebApp(), ri.getLocator(), "<zk></zk>", "zul");
		} else {
			return super.getPageDefinition(ri, path);
		}
		
	}
	
	public Desktop newDesktop(RequestInfo ri, String updateURI, String path) {
		final ServletRequest request = (ServletRequest)ri.getNativeRequest();
		final String url = Https.getOriginFullRequest(request);
		final Desktop desktop = super.newDesktop(ri, updateURI, path);
		desktop.setAttribute(DESKTOP_URL, url);
		return desktop;
	}

	public Page newPage(RequestInfo ri, PageDefinition pagedef, String path) {
		final ServletRequest request = (ServletRequest) ri.getNativeRequest();
		if (request.getAttribute(DESKTOP_REUSE) != null) {
			final Page page = (Page) ri.getDesktop().getPages().iterator().next();
			if (page instanceof ReusablePage) {
				((ReusablePage)page).setReuse(true);
				return page;
			} else {
				throw new IllegalStateException("Should be a ReuseablePage: "+page);
			}
		} else {
			return new ReusablePage(pagedef);
		}
	}

	public Page newPage(RequestInfo ri, Richlet richlet, String path) {
		final ServletRequest request = (ServletRequest) ri.getNativeRequest();
		if (request.getAttribute(DESKTOP_REUSE) != null) {
			final Page page = (Page) ri.getDesktop().getPages().iterator().next();
			if (page instanceof ReusablePage) {
				((ReusablePage)page).setReuse(true);
				return page;
			} else {
				throw new IllegalStateException("Should be a ReuseablePage: "+page);
			}
		} else {
			return new ReusablePage(richlet, path);
		}
	}
	
	private static class ReusablePage extends PageImpl {
		private boolean _reuse;

		public ReusablePage(PageDefinition pgdef) {
			super(pgdef);
		}
		public ReusablePage(Richlet richlet, String path) {
			super(richlet, path);
		}
		
		public void setReuse(boolean b) {
			_reuse = b;
		}
		
		//-- PageCtrl --//
		public void preInit() {
			if (_reuse) { //reuse, so don't preInit again
				return; 
			} else {
				super.preInit();
			}
		}
		
		public void init(PageConfig config) {
			if (_reuse) { //reuse, so don't init again
				tryRemoveLoginTemplateWindow();
				return; 
			} else {
				super.init(config);
			}
		}

		//Try to remove the login template window when login OK and reuse the desktop
		private void tryRemoveLoginTemplateWindow() {
			//remove the original popup window
			final Execution exec = Executions.getCurrent();
			final String uuid = ((ServletRequest)exec.getNativeRequest()).getParameter("rm");
			if (uuid != null) {
				final Component popupWin = exec.getDesktop().getComponentByUuidIfAny(uuid);
				if (popupWin != null) {
					Events.postEvent(new Event("onRemoveLoginWin", popupWin));
				}
			}
		}
	}
}
