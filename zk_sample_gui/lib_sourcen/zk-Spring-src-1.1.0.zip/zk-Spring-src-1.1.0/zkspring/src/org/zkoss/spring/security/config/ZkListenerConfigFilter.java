/* ZkListenerConfigFilter.java

{{IS_NOTE
	Purpose:
		
	Description:
		
	History:
		Oct 8, 2008 12:30:18 PM, Created by henrichen
}}IS_NOTE

Copyright (C) 2008 Potix Corporation. All Rights Reserved.

{{IS_RIGHT
	This program is distributed under GPL Version 2.0 in the hope that
	it will be useful, but WITHOUT ANY WARRANTY.
}}IS_RIGHT
*/
package org.zkoss.spring.security.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.ui.FilterChainOrder;
import org.springframework.security.ui.SpringSecurityFilter;
import org.springframework.web.context.ServletContextAware;
import org.zkoss.spring.security.intercept.zkevent.ZkEventProcessListener;
import org.zkoss.spring.security.ui.ZkExceptionTranslationListener;
import org.zkoss.zk.ui.WebApp;
import org.zkoss.zk.ui.http.WebManager;
import org.zkoss.zk.ui.util.Configuration;

/**
 * A Filter for lazy configuration of the ZK Spring listeners 
 * (e.g. ZkExceptionTranslationListener and ZkEventProcessListener)
 * @author henrichen
 * @since 1.0
 */
public class ZkListenerConfigFilter extends SpringSecurityFilter 
implements ServletContextAware {
    static final String FILTER_APPLIED = "__zk_spring_security_listener_config_filter_applied";
    protected final Log logger = LogFactory.getLog(getClass());

    private WebApp _webApp;
	private ServletContext _ctx;
	
	public void setServletContext(ServletContext ctx) {
		_ctx = ctx;
	}

	protected void doFilterHttp(HttpServletRequest request, 
	HttpServletResponse response, FilterChain chain) 
	throws IOException, ServletException {
        // If ever applied, go directly to next
        if(request.getSession(false) == null || request.getAttribute(FILTER_APPLIED) != null) {
            chain.doFilter(request, response);
            return;
        }
        
        request.setAttribute(FILTER_APPLIED, Boolean.TRUE);
        
		if (_webApp == null) {
			final WebManager webman = WebManager.getWebManager(_ctx);
			_webApp = webman.getWebApp();
			Configuration conf = _webApp.getConfiguration();
			try {
				conf.addListener(ZkSecurityContextListener.class);
				conf.addListener(ZkExceptionTranslationListener.class);
				conf.addListener(ZkEventProcessListener.class);
			} catch (Exception e) {
				//log and ignore
		        if (logger.isDebugEnabled()) {
		            logger.debug("Added ZK Spring Listeners Failed: " + e);
		        }
			}
		}
		
		chain.doFilter(request, response);
	}

	public int getOrder() {
		return FilterChainOrder.FILTER_CHAIN_FIRST + 10;
	}
}