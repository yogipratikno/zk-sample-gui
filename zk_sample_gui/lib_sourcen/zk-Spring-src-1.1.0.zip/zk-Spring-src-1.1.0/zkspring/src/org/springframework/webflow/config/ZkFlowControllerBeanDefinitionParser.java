/* ZkFlowControllerBeanDefinitionParser.java

{{IS_NOTE
	Purpose:
		
	Description:
		
	History:
		Nov 24, 2008 5:18:06 PM, Created by henrichen
}}IS_NOTE

Copyright (C) 2008 Potix Corporation. All Rights Reserved.

{{IS_RIGHT
	This program is distributed under GPL Version 2.0 in the hope that
	it will be useful, but WITHOUT ANY WARRANTY.
}}IS_RIGHT
*/

package org.springframework.webflow.config;

import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.StringUtils;
import org.springframework.webflow.executor.FlowExecutor;
import org.springframework.webflow.mvc.servlet.FlowController;
import org.w3c.dom.Element;
import org.zkoss.spring.js.ajax.ZkAjaxHandler;
import org.zkoss.spring.security.config.ZkBeanIds;
import org.zkoss.spring.webflow.context.servlet.ZkFlowUrlHandler;
import org.zkoss.spring.webflow.mvc.servlet.ZkFlowHandlerAdapter;

/**
 * <zksp:flow-controller flow-executor=""/>
 * @author henrichen
 * @since 1.1
 */
public class ZkFlowControllerBeanDefinitionParser 
extends AbstractSingleBeanDefinitionParser {
	private static final String FLOW_EXECUTOR = "flow-executor";

	protected Class getBeanClass(Element element) {
		return FlowController.class;
	}

	protected void doParse(Element element, ParserContext context, BeanDefinitionBuilder builder) {
		registerFlowHandlerAdaptor(element, context, builder);
	}
	
	private void registerFlowHandlerAdaptor(Element elm, ParserContext pc, BeanDefinitionBuilder rootBuilder) {
        final BeanDefinitionBuilder builder = 
        	BeanDefinitionBuilder.rootBeanDefinition(ZkFlowHandlerAdapter.class);
        registerFlowExecutor(elm, pc, builder);
        registerFlowUrlHandler(elm, pc, builder);
        registerAjaxHandler(elm, pc, builder);
        pc.getRegistry().registerBeanDefinition(ZkBeanIds.ZK_FLOW_HANDLER_ADAPTER, builder.getBeanDefinition());
        rootBuilder.addPropertyReference("flowHandlerAdapter", ZkBeanIds.ZK_FLOW_HANDLER_ADAPTER);
	}
	
	private void registerFlowUrlHandler(Element elm, ParserContext pc, BeanDefinitionBuilder rootBuilder) {
        final BeanDefinitionBuilder builder = 
        	BeanDefinitionBuilder.rootBeanDefinition(ZkFlowUrlHandler.class);
        pc.getRegistry().registerBeanDefinition(ZkBeanIds.ZK_FLOW_URL_HANDLER, builder.getBeanDefinition());
        rootBuilder.addPropertyReference("flowUrlHandler", ZkBeanIds.ZK_FLOW_URL_HANDLER);
	}
	
	private void registerAjaxHandler(Element elm, ParserContext pc, BeanDefinitionBuilder rootBuilder) {
        final BeanDefinitionBuilder builder = 
        	BeanDefinitionBuilder.rootBeanDefinition(ZkAjaxHandler.class);
        pc.getRegistry().registerBeanDefinition(ZkBeanIds.ZK_AJAX_HANDLER, builder.getBeanDefinition());
        rootBuilder.addPropertyReference("ajaxHandler", ZkBeanIds.ZK_AJAX_HANDLER);
	}
	
	private void registerFlowExecutor(Element elm, ParserContext pc, BeanDefinitionBuilder rootBuilder) {
        final BeanDefinitionBuilder builder = 
        	BeanDefinitionBuilder.rootBeanDefinition(FlowExecutor.class);
        final String flowExecutor = elm.getAttribute(FLOW_EXECUTOR); 
        rootBuilder.addPropertyReference("flowExecutor", StringUtils.hasText(flowExecutor) ? flowExecutor : "flowExecutor");
	}
}
