/* ZkEventProcessDefinitionSourceBeanDefinitionParser.java

{{IS_NOTE
	Purpose:
		
	Description:
		
	History:
		Oct 1, 2008 7:17:38 PM, Created by henrichen
}}IS_NOTE

Copyright (C) 2008 Potix Corporation. All Rights Reserved.

{{IS_RIGHT
	This program is distributed under GPL Version 2.0 in the hope that
	it will be useful, but WITHOUT ANY WARRANTY.
}}IS_RIGHT
*/
package org.springframework.webflow.config;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.PropertyValue;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.binding.convert.service.DefaultConversionService;
import org.springframework.security.ConfigAttributeEditor;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.ConfigUtils;
import org.springframework.security.config.ZkEventSecurityBeanDefinitionParser;
import org.springframework.security.util.AntUrlPathMatcher;
import org.springframework.security.util.RegexUrlPathMatcher;
import org.springframework.security.util.UrlMatcher;
import org.springframework.util.StringUtils;
import org.springframework.util.xml.DomUtils;
import org.springframework.webflow.expression.DefaultExpressionParserFactory;
import org.springframework.webflow.mvc.builder.MvcViewFactoryCreator;
import org.w3c.dom.Element;
import org.zkoss.spring.binding.convert.service.ZkConversionService;
import org.zkoss.spring.security.config.ZkBeanIds;
import org.zkoss.spring.security.intercept.zkevent.EventProcessKey;
import org.zkoss.spring.security.intercept.zkevent.ZkEventProcessDefinitionSource;
import org.zkoss.spring.security.ui.ZkLoginOKFilter;
import org.zkoss.spring.web.servlet.view.ZkFlowResourceViewResolver;
import org.zkoss.spring.web.servlet.view.ZkView;
import org.zkoss.spring.webflow.engine.builder.ZkFlowViewFactoryCreator;
import org.zkoss.spring.webflow.expression.el.ZkExpressionParser;

/**
 * Allows for convenient creation of a {@link ZkEventProcessDefinitionSource} 
 * bean for use with a ZkEventProcessInterceptor.
 * @author henrichen
 * @since 1.1
 */
public class ZkFlowBuilderServicesBeanDefinitionParser 
extends	FlowBuilderServicesBeanDefinitionParser {
	
	//override
	protected void doParse(Element element, ParserContext context, BeanDefinitionBuilder builder) {
		registerConversionService(element, context, builder);
		registerExpressionParser(element, context, builder);
		registerMvcViewFactoryCreator(element, context, builder);
	}
	
	private void registerConversionService(Element element, ParserContext pc, BeanDefinitionBuilder rootBuilder) { 
        final BeanDefinitionBuilder builder = 
        	BeanDefinitionBuilder.rootBeanDefinition(ZkConversionService.class);
        pc.getRegistry().registerBeanDefinition(ZkBeanIds.ZK_CONVERSION_SERVICE, builder.getBeanDefinition());
        rootBuilder.addPropertyReference("conversionService", ZkBeanIds.ZK_CONVERSION_SERVICE);
	}
	private void registerExpressionParser(Element element, ParserContext pc, BeanDefinitionBuilder rootBuilder) { 
        final BeanDefinitionBuilder builder = 
        	BeanDefinitionBuilder.rootBeanDefinition(ZkExpressionParser.class);
        pc.getRegistry().registerBeanDefinition(ZkBeanIds.ZK_EXPRESSION_PARSER, builder.getBeanDefinition());
        rootBuilder.addPropertyReference("expressionParser", ZkBeanIds.ZK_EXPRESSION_PARSER);
	}
	private void registerMvcViewFactoryCreator(Element element, ParserContext pc, BeanDefinitionBuilder rootBuilder) { 
        final BeanDefinitionBuilder builder = 
        	BeanDefinitionBuilder.rootBeanDefinition(ZkFlowViewFactoryCreator.class);
        registerViewResolvers(element, pc, builder);
        pc.getRegistry().registerBeanDefinition(ZkBeanIds.ZK_FLOW_VIEW_FACTORY_CREATOR, builder.getBeanDefinition());
        rootBuilder.addPropertyReference("viewFactoryCreator", ZkBeanIds.ZK_FLOW_VIEW_FACTORY_CREATOR);
	}
	private void registerViewResolvers(Element element, ParserContext pc, BeanDefinitionBuilder rootBuilder) {
        final BeanDefinitionBuilder builder = 
        	BeanDefinitionBuilder.rootBeanDefinition(ZkFlowResourceViewResolver.class);
		//TODO: allow config prefix and suffix
        builder.addPropertyValue("suffix", ".zul");
        builder.addPropertyValue("viewClass", ZkView.class);
        pc.getRegistry().registerBeanDefinition(ZkBeanIds.ZK_FLOW_RESOURCE_VIEW_RESOLVER, builder.getBeanDefinition());
        rootBuilder.addPropertyReference("viewResolvers", ZkBeanIds.ZK_FLOW_RESOURCE_VIEW_RESOLVER);
	}
}
